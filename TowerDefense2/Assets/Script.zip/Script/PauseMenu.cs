﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public static bool GameIsPaused = false;

    public GameObject PauseMenuUI;
    public GameObject GameOverUI;

    public static bool GameIsOver = false;
     public AudioSource pauseAudio;
    



    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (GameIsPaused)
            {
                Resume();
            }
            else if (!GameIsOver)
            {
                Pause();
            }
        }

        if (TowerScript.lives <= 0 || Input.GetKeyDown(KeyCode.L)) //L Debug, togliere!
        {
            if (!GameIsOver)
            {
                GameOver();
                GameIsOver = false;
            }
        }
    }

    public void Resume()
    {
        PauseMenuUI.SetActive(false);
        Time.timeScale = 1f;
        GameIsPaused = false;
    }

    void Pause()
    {
        PauseMenuUI.SetActive(true);
        pauseAudio.Play();
        Time.timeScale = 0f;
        GameIsPaused = true;
    }

    public void LoadMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Menu");
    }

    public void QuitGame()
    {
        Debug.Log("Uscita in corso...");
        UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();
    }

       void GameOver()
    {
        
        GameOverUI.SetActive(true);
        Time.timeScale = 0f;
        GameIsOver = true;
        
    }


}
