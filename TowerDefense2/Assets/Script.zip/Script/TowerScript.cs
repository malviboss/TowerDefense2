﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TowerScript : MonoBehaviour
{
    Animator towerAnim;
    public static bool isDead;
    AnimatorClipInfo[] m_CurrentClipInfo;
    SpriteRenderer sr;
    Rigidbody2D rb;
    public GameObject heart1T, heart2T, heart3T, gameOverText, restartButton, torretta1, torretta2, fire;
    public static int lives = 3;
    float m_CurrentClipLength;
    public AudioSource hit, gameOverAudio;
 public float delay = 0f;
    // Start is called before the first frame update
    void Start()
    {        
        sr = GetComponent<SpriteRenderer>();
        heart1T = GameObject.Find("heart1T");
        heart2T = GameObject.Find("heart2T");
        heart3T = GameObject.Find("heart3T");
      /*  gameOverText = GameObject.Find("GameOverText");
        restartButton = GameObject.Find("RestartButton");
        gameOverText.SetActive(false);
        restartButton.SetActive(false);*/
        heart1T.gameObject.SetActive(true);
        heart2T.gameObject.SetActive(true);
        heart3T.gameObject.SetActive(true);
        hit = GetComponent<AudioSource>();
        towerAnim = gameObject.GetComponent<Animator>();
        m_CurrentClipInfo = towerAnim.GetNextAnimatorClipInfo(0);

//        m_CurrentClipLength = m_CurrentClipInfo[0].clip.length;



        isDead = false;

        rb = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
                //prove varie di debug
        if (Input.GetKeyDown(KeyCode.G))
        {

            lives = lives - 1;
            if (lives > 0)
            {
                hit.Play();
            } else if (lives == 0){
                gameOverAudio.Play();
            }

            Debug.Log("Vite scese a " + lives + "");
            sr.color = new Color(2, 0, 0);//set this object's red color to 200 percent
        }
        switch (lives)
        {
            case 2:
                sr.color = Color.Lerp(sr.color, Color.white, Time.deltaTime / 0.3f);//slowly linear interpolate. takes about 3 seconds to return to white
                heart3T.gameObject.SetActive(false);
                torretta1.SetActive(false);
                break;
            case 1:
                sr.color = Color.Lerp(sr.color, Color.white, Time.deltaTime / 0.3f);//slowly linear interpolate. takes about 3 seconds to return to white
                heart2T.gameObject.SetActive(false);
                torretta2.SetActive(false);
                break;
            case 0:
                heart1T.gameObject.SetActive(false);         //cambia parametro in animator per attivare animazione di morte
                isDead = true; //al prossimo frame aggiornerà animazione
                fire.SetActive(true);
                //Debug.Log("Morto");
                break;
        }


        if (isDead == true)
        {

             towerAnim.SetBool("isDead", true);
           // towerAnim.Play("TorreDistrutta"); // WHYYYYYY
           //  m_CurrentClipInfo = towerAnim.GetCurrentAnimatorClipInfo(0);
             //m_CurrentClipLength = m_CurrentClipInfo[0].clip.length;
            //distrugge l'oggetto dopo aver aspettato il numero di secondi
            //necessari a mostrare l'animazione
           // Debug.Log("TEMPOOOO " + m_CurrentClipLength);
           // Destroy (gameObject, 2f); 
           // gameOverText.SetActive(true);
          //  restartButton.SetActive(true);
           // Time.timeScale = 0;  
        }
    }



  void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag.Equals("Enemy"))
        {

            Destroy(col.gameObject);
            sr.color = new Color(2, 0, 0);//set this object's red color to 200 percent
            lives = lives - 1;
            if (lives != 0)
            {
                hit.Play();
            }
            else if (lives == 0)
            {
                gameOverAudio.Play();
            }
        }
    }



}
